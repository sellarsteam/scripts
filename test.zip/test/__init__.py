from datetime import datetime
from json import load, JSONDecodeError
from os import getcwd
from typing import Union, List

from jsonpath2 import Path

from source import logger
from source import api
from source.cache import HashStorage
from source.api import CatalogType, TargetType, RestockTargetType, ItemType, TargetEndType, IAnnounce, IRelease, TEFail, IRestock, TESoldOut, TESuccess
from source.library import SubProvider


# TODO: Bug (error on import library, all monitor stops)


class Parser(api.Parser):
    interval: int = 3

    def __init__(self, name: str, log: logger.Logger, provider_: SubProvider):
        super().__init__(name, log, provider_)
        self.pattern = '%Y-%m-%dT%H:%M:%S.%fZ'

    @property
    def catalog(self) -> CatalogType:
        return api.CInterval(self.name, 10.)

    def execute(
            self,
            mode: int,
            content: Union[CatalogType, TargetType]
    ) -> List[Union[CatalogType, TargetType, RestockTargetType, ItemType, TargetEndType]]:
            if mode == 0:
                result = [
                    api.TInterval(i.current_value['name'], self.name, i.current_value['name'], 1.5)
                    for i in Path.parse_str('$.collections[*][?(@.items[0].availability = true)]').match(load(open(f'{getcwd()}/scripts/test/api.json')))
                ]
                result.append(self.catalog)
                return result
            elif mode == 1:
                try:
                    items = [i['items'] for i in load(open(f'{getcwd()}/scripts/test/api.json'))['collections'] if i['name'] == content.data][0]
                except JSONDecodeError:
                    return [api.TEFail(content, 'Bad json')]
                except KeyError:
                    return [api.TEFail(content, 'Bad schema')]

                result = []
                has_announce = False

                for i in items:
                    data = [
                        f'https://test.com/product/{i["id"]}',
                        'test',
                        i['name'],
                        f'https://cdn.test.com/preview/{i["id"]}',
                        i['description'],
                        api.Price(api.CURRENCIES['RUB'], float(i['price']['current']), float(i['price']['full'])),
                        api.Sizes(api.SIZE_TYPES['S-US-M'], (api.Size(float(j), f'https://test.com/buy/{i["id"]}?size={j}') for j in i['sizes']))
                    ]

                    if datetime.strptime(i['release_date'], self.pattern) < datetime.utcnow():
                        item = api.IRelease(*data)
                        if HashStorage.check_item(item.hash(4)):
                            result.append(item)
                    else:
                        has_announce = True
                        item = api.IAnnounce(*data)
                        if HashStorage.check_item(item.hash(3), True):
                            result.append(item)

                if result or has_announce:
                    result.append(content)
                    return result
                else:
                    return [api.TESuccess(content)]


class EventsExecutor(api.EventsExecutor):
    def e_item_announced(self, item: IAnnounce) -> None:
        self.log.info(f'IAnnounce: {item}')

    def e_item_released(self, item: IRelease) -> None:
        self.log.info(f'IRelease: {item}')

    def e_item_restock(self, item: IRestock) -> None:
        self.log.info(f'IRestock: {item}')

    def e_target_end_fail(self, target_end: TEFail) -> None:
        self.log.warn(f'TEFailed: {target_end}')

    def e_target_end_sold_out(self, target_end: TESoldOut) -> None:
        self.log.info(f'TESoldOut: {target_end}')

    def e_target_end_success(self, target_end: TESuccess) -> None:
        self.log.info(f'TESuccess: {target_end}')

